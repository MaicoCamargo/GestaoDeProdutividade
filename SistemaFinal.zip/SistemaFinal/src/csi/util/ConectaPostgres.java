package csi.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConectaPostgres {

		
	public static Connection conectaBD()
	{
		Connection criaConexaoBD = null;
		try {
			Class.forName("org.postgresql.Driver");//onde � informado o banco que vai se usado
			String url= "jdbc:postgresql://localhost:5432/BdSistemaFinal";
			String usuario="postgres";//usuario do banco que por padrao � esse
			String senha = "0000";
			criaConexaoBD = DriverManager.getConnection(url,usuario,senha);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("erro ao conectar com o banco");
		}
		//System.out.println("CONECTADO AO BANCO DE DADOS");
		return criaConexaoBD;
	}
}
