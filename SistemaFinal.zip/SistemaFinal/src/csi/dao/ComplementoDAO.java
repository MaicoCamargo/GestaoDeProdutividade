package csi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import csi.modelo.Complemento;
import csi.util.ConectaPostgres;

public class ComplementoDAO {

	public ArrayList<Complemento> VerComplementos()//como vou retornar todos nao a nececcidade de passar um parametro
	{
		String sql ="select * from complemento";
		Connection conexaoBd = ConectaPostgres.conectaBD();
		try {
			PreparedStatement ps = conexaoBd.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();//tem retorno do que entao query
			ArrayList<Complemento> listaComplemento = new ArrayList<>();
			while (rs.next()) {
				Complemento cmp =  new Complemento();
				cmp.setNome(rs.getString("nome"));//puxando do banco e jogando pro obj direto sem criar uma variavel pra isso
				cmp.setMarca(rs.getString("marca"));
				cmp.setId(rs.getInt("id"));
				cmp.setObservacao(rs.getString("obs"));
				cmp.setTipo(rs.getString("tipo"));
				listaComplemento.add(cmp);
				
			}
			for (Complemento complemento2 : listaComplemento) {
				System.out.println(" metodo ver complementos>"+complemento2.getId());
			}
			return listaComplemento;
		} catch (Exception e) {
			System.out.println("ver complementos, erro"+e.getMessage());
		}
		return null;
	}
	

	public boolean InsereComplemento(Complemento comp)
	{
		System.out.println("metodo insere");
		Connection conexaoComBanco = ConectaPostgres.conectaBD();
		String sql = "insert into complemento (nome,marca,tipo,obs) values (?,?,?,?)";
		try {
			PreparedStatement ps = conexaoComBanco.prepareStatement(sql);
			ps.setString(1, comp.getNome());
			ps.setString(2, comp.getMarca());
			ps.setString(3, comp.getTipo());
			ps.setString(4, comp.getObservacao());
			ps.execute();//quando nao tem retorno usasse execute
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("erro");
		}
		return false;
	}

	public boolean EditaComplemnto(Complemento c){
		Connection conexaoBd = ConectaPostgres.conectaBD();
		
		String sql="update complemento set nome=?,marca=?,tipo=?,obs=? where id=?";
		try {
			PreparedStatement pst = conexaoBd.prepareStatement(sql);
			pst.setString(1, c.getNome());
			pst.setString(2,c.getMarca());
			pst.setString(3,c.getTipo());
			pst.setString(4,c.getObservacao());
			pst.setInt(5, c.getId());
			
			pst.execute();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
	
	public boolean ApagarComplemento(int id){
		Connection conexao = ConectaPostgres.conectaBD();
		String sql= "delete from complemento where id=?";
		try {
			PreparedStatement pre = conexao.prepareStatement(sql);
			pre.setInt(1, id);
			pre.execute();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

}
