package csi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import csi.modelo.Usuario;
import csi.util.ConectaPostgres;

public class UsuarioDAO {
	
	public boolean CadastrarUsuario(Usuario usuarioCadastrar)
	{
		//cadastrar usuario
		
		try {
			
			Connection conexaoBanco = ConectaPostgres.conectaBD();
			String sql = "insert into usuario (nome,telefone,senha,email) values (?,?,?,?)";
			PreparedStatement pst = conexaoBanco.prepareStatement(sql);
			
			pst.setString(1, usuarioCadastrar.getNome());
			pst.setString(2, usuarioCadastrar.getTelefone());
			pst.setString(3, usuarioCadastrar.getSenha());
			pst.setString(4, usuarioCadastrar.getEmail());
		    pst.execute();
		    
		    
			return true;

		} catch (Exception e) {
			System.out.println("erro no cadastro do usuario");
			// TODO: handle exception
		}
		return false;
	}

	public Usuario VerUsuarioRecemCadastrado(Usuario usu) //retornara o usuario que acabou de cadastrar no sistema para criar uma sess�o pra ele
	{
		//System.out.println("-----");
		Connection conectaBanco  = ConectaPostgres.conectaBD();
		String sql="select nome,telefone,email from usuario where nome=? and telefone=? and email=?";
		try {
			//System.out.println("====");
			PreparedStatement pst = conectaBanco.prepareStatement(sql);
			//System.out.println("nome"+usu.getNome());
			pst.setString(1, usu.getNome());
			pst.setString(2, usu.getTelefone());
			pst.setString(3, usu.getEmail());
			
			ResultSet rs= pst.executeQuery();
			//System.out.println("query");
			while (rs.next()) {
				String nome = rs.getString("nome");
				//System.out.println("<nome>"+nome);
				Usuario u = new Usuario();
				u.setNome(nome);
				//System.out.println("<><"+u.getNome());
				return u;
				
			}
		} catch (Exception e) {
			System.out.println("erro no fazer a sess�o para o usuario recem cadastrado");
		}
		return null;
	}

	public Usuario AutenticarLogin(Usuario usuLogar)
	{
		
		Connection conectaBd = ConectaPostgres.conectaBD();
		String sql ="select nome,telefone,email,id,senha from usuario where senha=? and nome=?";
		try {
			PreparedStatement ps = conectaBd.prepareStatement(sql);
			ps.setString(1, usuLogar.getSenha());
			ps.setString(2, usuLogar.getNome());
			ResultSet rs= ps.executeQuery();
			while (rs.next()) {
				Usuario usu_logado = new Usuario();
				usu_logado.setNome(rs.getString("nome"));//puxando do banco com o rs e setando pro usuario que retornara
				usu_logado.setEmail(rs.getString("email"));
				usu_logado.setTelefone(rs.getString("telefone"));
				usu_logado.setSenha(rs.getString("senha"));
				usu_logado.setId(rs.getInt("id"));
				return usu_logado;
			}
			
		} catch (Exception e) {
			System.out.println("erro dentro do metodo que autentica o logar");
		}
		return null;
	}

	public boolean EditarUsuario(Usuario us){
		Connection conexaobd = ConectaPostgres.conectaBD();
		String sql="update usuario set nome=?,telefone=?,email=?, senha=? where id=?"; 
		try {
			PreparedStatement pp = conexaobd.prepareStatement(sql);
			pp.setString(1, us.getNome());
			pp.setString(2, us.getTelefone());
			pp.setString(3, us.getTelefone());
			pp.setString(4, us.getEmail());
			pp.setInt(5, us.getId());
			pp.execute();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
}