package csi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import csi.modelo.Cultivo;
import csi.util.ConectaPostgres;

public class CultivoDAO {

	public boolean InseriCultivo(Cultivo cul)
	{
		Connection conectaBanco = ConectaPostgres.conectaBD();
		String sql ="insert into cultivo (nome,variedade,obs) values (?,?,?)";
		try {
			PreparedStatement ps = conectaBanco.prepareStatement(sql);
			ps.setString(1, cul.getNome());
			ps.setString(2, cul.getVariedade());
			ps.setString(3, cul.getObservacao());
			ps.execute();//quando nao tem retorno do sql usasse apenas execute
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("erramos");
		}
		return false;
	}
	
	public ArrayList<Cultivo> VerCultivos()
	{
		Connection conectaBd = ConectaPostgres.conectaBD();
		String sql = "select * from cultivo";
		ArrayList<Cultivo> listaDeCultivos = new ArrayList<>();//criado o array list 
		try {
			PreparedStatement ps = conectaBd.prepareStatement(sql);
			ResultSet reSet= ps.executeQuery();
			while (reSet.next()) {
				Cultivo c = new Cultivo();
				/*String nome = reSet.getString("nome");
				c.setNome(nome);  essas linhas sao a mesma coisa que as linhas de baixo*/
				c.setId(reSet.getInt("id"));
				c.setNome(reSet.getString("nome"));
				c.setObservacao(reSet.getString("obs"));
				c.setVariedade(reSet.getString("variedade"));
				listaDeCultivos.add(c);
			}
			
			//for (Cultivo cultivo : listaDeCultivos) {
			//	System.out.println("CM"+cultivo.getNome());
			//}
			
			return listaDeCultivos;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	public boolean EditarCultivo( Cultivo cul){
		System.out.println("dentro do metodo editar");
		Connection conexao = ConectaPostgres.conectaBD();
		String sql ="UPDATE cultivo SET nome=?,variedade=?, obs=? WHERE id=?";
		try {
			PreparedStatement pst = conexao.prepareStatement(sql);
			pst.setString(1, cul.getNome());
			pst.setString(2, cul.getVariedade());
			pst.setString(3, cul.getObservacao());
			pst.setInt(4, cul.getId());
			pst.execute();
			System.out.println("fiz o update e retornei true");
			return true;
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

	public boolean ApagarCultivo(int id){
		Connection conexao = ConectaPostgres.conectaBD();
		String sql= "delete from cultivo where id=?";
		try {
			PreparedStatement pre = conexao.prepareStatement(sql);
			pre.setInt(1, id);
			pre.execute();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

	public Cultivo VerCultivoComId(int id){
		Connection conexaobd = ConectaPostgres.conectaBD();
		String sql="select * from cultivo where id=?";
		try {
			PreparedStatement pstmt = conexaobd.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet result = pstmt.executeQuery();
			Cultivo c = new Cultivo();
			while(result.next()){
				
				c.setNome(result.getString("nome"));
				c.setObservacao(result.getString("obs"));
				c.setVariedade(result.getString("variedade"));
				c.setId(result.getInt("id"));
			}
			return c;//obj cultivo com todos os dados retornados do banco
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
}
