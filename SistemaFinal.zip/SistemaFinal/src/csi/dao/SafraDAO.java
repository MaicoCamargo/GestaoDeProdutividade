package csi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import csi.modelo.Complemento;
import csi.modelo.Cultivo;
import csi.modelo.Safra;
import csi.util.ConectaPostgres;

public class SafraDAO {

   public boolean CriarSafra(Safra saf){

	   
	   Connection ConexaoBanco = ConectaPostgres.conectaBD();
	   //String sql = "insert into safra (codcultivo,codcomplemento,areacultivada,kiloscomplemento,kiloscultivo,datainicio) values(?,?,?,?,?,?)"; sem a data
	   String sql = "insert into safra (codcultivo,codcomplemento,areacultivada,kiloscomplemento,kiloscultivo) values(?,?,?,?,?)";
	   try {
		PreparedStatement prep = ConexaoBanco.prepareStatement(sql);
		prep.setInt(1, saf.getCodCultivo());
		prep.setInt(2, saf.getCodComplemento());
		prep.setFloat(3, saf.getAreaCultivar());
		prep.setFloat(4, saf.getKilosComplemento());
		prep.setFloat(5, saf.getKilosCultivo());
		prep.execute();//quando nao tem retorno do banco 
		return true;
		
	} catch (Exception e) {
		// TODO: handle exception
	}
	   return false;
   }
   
   public ArrayList<Safra> VerSafraComId(Safra saf){
	   Connection conexao = ConectaPostgres.conectaBD();
	   String sql = "select * from safra where id =?";
	   ArrayList<Safra> lista = new ArrayList<Safra>();
	   try {
		   PreparedStatement pre =  conexao.prepareStatement(sql);
		   pre.setInt(1, saf.getId());
		  ResultSet rs=  pre.executeQuery();
		  while(rs.next()){
			  Safra safra= new Safra();
			  safra.setAreaCultivar(rs.getFloat("areacultivada"));
			  safra.setKilosCultivo(rs.getFloat("kiloscultivo"));
			  lista.add(safra);
			  System.out.println("---->"+safra.getAreaCultivar());
		  }
		  return lista;
		  
	} catch (Exception e) {
		// TODO: handle exception
	}
	   return null;
   }

   public boolean InsereOutroComplemento(Safra safr){
	   Connection conexaoBd = ConectaPostgres.conectaBD();
	   String sql = "update safra set codcomplemento=?,areacultivada=?,kiloscultivo=?,kiloscomplemento=? where codcultivo=?";
	   try {
		PreparedStatement pt =  conexaoBd.prepareStatement(sql);
		
		pt.setInt(1, safr.getCodComplemento());
		pt.setFloat(2, safr.getAreaCultivar());
		pt.setFloat(3, safr.getKilosCultivo());
		pt.setFloat(4, safr.getKilosComplemento());
		pt.setInt(5, safr.getCodCultivo());
		//falta a data
		pt.execute();
		System.out.println("fiz o update e retornei true");
		return true;
	} catch (Exception e) {
		System.out.println("erro no try chath");
	}
	return false;   
   }
   
   
   public ArrayList<Complemento> VerificaComplementosJaAdicionados(int idCultivo){
	   Connection conexaobd = ConectaPostgres.conectaBD();
	   String sql="SELECT id,nome FROM complemento where complemento.id not in (select codcomplemento from safra where codcultivo=?)";
	   ArrayList<Complemento> listaNaoUsados= new ArrayList<>();//lista de complementos nao usados
	   try {
		   
		   PreparedStatement ps = conexaobd.prepareStatement(sql);
		   ps.setInt(1, idCultivo);
		   ResultSet re_Set = ps.executeQuery();
		   while(re_Set.next()){
			   Complemento c = new Complemento();
			   c.setNome(re_Set.getString("nome"));
			   c.setId(re_Set.getInt("id"));
			   listaNaoUsados.add(c);
		   }
		   return listaNaoUsados;
		   
	} catch (Exception e) {
		// TODO: handle exception
	}
	return null;
   }
   
   public ArrayList<Cultivo> CultivoJaCadastradosNaSafra(){//saber os cultivos que estao na tabela safra
	   Connection conBancoDeDados = ConectaPostgres.conectaBD();
	   String sql ="select id, nome From cultivo where cultivo.id in (select codcultivo from safra)";//sql que retorna os ids dos cultivos que ja est�o na tabela safra
	   try {
		PreparedStatement prestatm = conBancoDeDados.prepareStatement(sql);
		ArrayList<Cultivo> listaDEcadastradasNaSafra = new ArrayList<>();
		ResultSet resultSet = prestatm.executeQuery();
		while(resultSet.next()){
			Cultivo c = new Cultivo();
			c.setId(resultSet.getInt("id"));
			c.setNome(resultSet.getString("nome"));
			listaDEcadastradasNaSafra.add(c);
		}
		
		return listaDEcadastradasNaSafra;
	} catch (Exception e) {
		System.out.println("erro no retorno do banco");
	}
	   return null;
   }

   public Safra VerSafraSelecionada(int idCultivo){//retorna os dados kilo de cul e compl e a area o resto buscasse em ComplementoDAO e CultivoDAO
	   Connection conexaobd = ConectaPostgres.conectaBD();
	   String sql="select * from safra where codcultivo=?";
	   try {
		PreparedStatement pst = conexaobd.prepareStatement(sql);
		pst.setInt(1, idCultivo);
		ResultSet rs =pst.executeQuery();
		Safra sa = new Safra();
		while(rs.next()){	
			sa.setAreaCultivar(rs.getFloat("areacultivada"));
			sa.setKilosComplemento(rs.getFloat("kiloscomplemento"));
			sa.setKilosCultivo(rs.getFloat("kiloscultivo"));
			sa.setCodCultivo(rs.getInt("codcultivo"));
		}
		return sa;
	} catch (Exception e) {
		// TODO: handle exception
	}
	   return null;
   }
   
   public ArrayList<Complemento> VerDadosDosComplementosDaSafraEscolhida( int idCultivo){
	   Connection conexaobd = ConectaPostgres.conectaBD();
	   String sql="select codcomplemento from safra where codcultivo=?";//busca os ids no banco
	   try {
		PreparedStatement pst= conexaobd.prepareStatement(sql);
		pst.setInt(1, idCultivo);
		ResultSet rSet = pst.executeQuery();
		ArrayList<Integer> listaDeIds = new ArrayList<>();
		while(rSet.next()){
			
			int id= rSet.getInt("codcomplemento");//adicionando os ids dentro do array direto sem outras variaveis
			listaDeIds.add(id);//colocando os ids dentro de uma lista pra fazer uma nova consulta no banco
		}
		
		ArrayList< Complemento> listaDeComplementos = new ArrayList<>();//lista dos dados do complemento
		int cont=0;//contador do laco que vai buscar os dados do complemento no banco
		
		while(cont< listaDeIds.size()){
			String queryBuscaDadosComplemento = "select * from complemento where  id=?";
			PreparedStatement pres = conexaobd.prepareStatement(queryBuscaDadosComplemento);	
			pres.setInt(1, listaDeIds.get(cont));
			
			ResultSet rs = pres.executeQuery();
			
			while(rs.next()){
				
				Complemento cmp = new Complemento();
				cmp.setMarca(rs.getString("marca"));
				cmp.setNome(rs.getString("nome"));
				cmp.setObservacao(rs.getString("obs"));
				cmp.setTipo(rs.getString("tipo"));
				cmp.setId(rs.getInt("id"));
				listaDeComplementos.add(cmp);//adicionando para o array
			}
			cont++;
		}
		
		System.out.println("true");
		return listaDeComplementos;//lista com os dado de cada complemento que esta naquela safra
	} catch (Exception e) {
		System.out.println("weero");
		System.out.println(e.getMessage());
	}
	   return null;
   }
   
   public ArrayList<Safra> VerQuantidadeDeCadaComplemento(int idCultivo){
	   Connection conexaobd = ConectaPostgres.conectaBD();

	   String sql="select codcomplemento from safra where codcultivo=?";//busca os ids no banco
	   try {
		PreparedStatement pst= conexaobd.prepareStatement(sql);
		pst.setInt(1, idCultivo);
		ResultSet rSet = pst.executeQuery();
		ArrayList<Integer> listaDeIds = new ArrayList<>();
		while(rSet.next()){	
			int id= rSet.getInt("codcomplemento");//adicionando os ids dentro do array direto sem outras variaveis
			listaDeIds.add(id);//colocando os ids dentro de uma lista pra fazer uma nova consulta no banco
		}
	    
		int cont=0;
	    ArrayList<Safra> listaDeQuantidades = new ArrayList<>();
		while(cont<listaDeIds.size()){
			String buscaQtds = "select kiloscomplemento,codcomplemento from safra where codcomplemento=?";
			PreparedStatement p = conexaobd.prepareStatement(buscaQtds);
			p.setInt(1, listaDeIds.get(cont));
			ResultSet resultSet = p.executeQuery();
			while(resultSet.next()){
				Safra sa = new Safra();
				sa.setKilosComplemento(resultSet.getFloat("kiloscomplemento"));
				sa.setCodComplemento(resultSet.getInt("codcomplemento"));
				System.out.println("teste:"+sa.getCodComplemento());
				listaDeQuantidades.add(sa);
			}
			
			cont++;
		}
		   
		   
		   return listaDeQuantidades;
	} catch (Exception e) {
		System.out.println("erro"+e.getMessage());
	}
	   
	   return null;
   }

   public boolean EditarAreaDeCultivo(int id, float novoValor){//editar a area de cultivo de um cultivo dentro da safra
	   Connection conexao = ConectaPostgres.conectaBD();
	   String sql ="update safra set areacultivada=? where codcultivo=?";
	   try {
		PreparedStatement preSt = conexao.prepareStatement(sql);
		preSt.setFloat(1, novoValor);
		preSt.setInt(2, id);
		preSt.execute();
		return true;
	} catch (Exception e) {
		System.out.println("algo deu errado no update da area"+e.getMessage());
	}
	   return false;
   }

   public boolean EditarQuilosDeSemente(int id, float novoValor){
	   System.out.println("vim no metodo do update");
	   Connection conexao = ConectaPostgres.conectaBD();
	   String sql = "update safra set kiloscultivo=? where codcultivo=?";
	   try {
		PreparedStatement preSte = conexao.prepareStatement(sql);
		preSte.setFloat(1, novoValor);
		preSte.setInt(2, id);
		preSte.execute();
		return true;
	} catch (Exception e) {
		System.out.println("erro no update de kilos");
	}
	return false;
   }

   public boolean ApagarSafra(int id){
	   Connection conexao =  ConectaPostgres.conectaBD();
	   String sql="delete from safra where codcultivo=?";
	   try {
		PreparedStatement pst = conexao.prepareStatement(sql);
		pst.setInt(1, id);
		pst.execute();
		return true;
	} catch (Exception e) {
		// TODO: handle exception
	}
	   return false;
   }
}
