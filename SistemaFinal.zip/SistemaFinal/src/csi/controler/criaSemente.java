package csi.controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.bcel.internal.generic.NEW;

import csi.dao.ComplementoDAO;
import csi.dao.CultivoDAO;
import csi.dao.UsuarioDAO;
import csi.modelo.Cultivo;

@WebServlet("/criaSemente")
public class criaSemente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public criaSemente() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String op = request.getParameter("opcao");//saber o que o usuario quer fazer
		
		if(op.equals("0"))//valor zero quer dizer que o usuario quer inserir e retornar ao menu de criacao de dados
		{
			System.out.println("insere e volta pro menu");
			chamaMetodoQueInsereNoBanco(request, response);//e volta para o menu
			
			String pagina="/WEB-INF/jsp/CriaSementeComplemento.jsp";
			RequestDispatcher despacha = request.getServletContext().getRequestDispatcher(pagina);
			request.setAttribute("todasSementes",new CultivoDAO().VerCultivos());
			request.setAttribute("todosComplementos", new ComplementoDAO().VerComplementos()); 
			despacha.forward(request, response);
		}
		else//valor um quer dizer que o usuario quer inserir e outra semente
		{
			//implementar uma mensagem de retorno depois que for inserido um cultivo
			System.out.println("inserir outra");
			chamaMetodoQueInsereNoBanco(request, response);
			String pagina="/WEB-INF/jsp/add_Semente.jsp";
			RequestDispatcher despacha = request.getServletContext().getRequestDispatcher(pagina);
			despacha.forward(request, response);
		}
		
	}
	
	public void chamaMetodoQueInsereNoBanco(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String nomeDoCultivo = request.getParameter("nomeDoCultivo");
		String variedade = request.getParameter("variedade");
		String obs = request.getParameter("observacao");
		Cultivo cultivoDoForm = new Cultivo(nomeDoCultivo,variedade,obs);
		boolean dao = new CultivoDAO().InseriCultivo(cultivoDoForm);
		if(dao) //retornar ao menu de criacao de dados
		{
			System.out.println("inserido");//mensagem no servidor de inserido
		}
		else
		{
			System.out.println("nao inserido");//mensagem no servidor de inserido
		}
	}
	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
