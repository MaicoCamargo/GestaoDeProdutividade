package csi.controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csi.dao.ComplementoDAO;
import csi.dao.CultivoDAO;
import csi.modelo.Cultivo;

/**
 * Servlet implementation class caminhoCriaSemente
 */
@WebServlet("/caminhoCriaSementeComplemento")//----> diferente do nome do arquivo
public class caminhoCriaSementeEcomplemento extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public caminhoCriaSementeEcomplemento() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pg = "/WEB-INF/jsp/CriaSementeComplemento.jsp";
		RequestDispatcher despacha;
		Cultivo cultivo = new Cultivo();//criado para mandar por parametro para que o metodo poder retornar os cultivos
		request.setAttribute("todasSementes", new CultivoDAO().VerCultivos());
		request.setAttribute("todosComplementos", new ComplementoDAO().VerComplementos());
		despacha= request.getServletContext().getRequestDispatcher(pg);
		despacha.forward(request, response);
		//depois colocar o for each do complemento
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
