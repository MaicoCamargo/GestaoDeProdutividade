package csi.controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csi.dao.CultivoDAO;
import csi.dao.SafraDAO;

/**
 * Servlet implementation class editaSafra
 */
@WebServlet("/editaSafra")
public class editaSafra extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public editaSafra() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String op = request.getParameter("op");
		if(op.equals("area")){
			String novaArea = request.getParameter("novoValor");
			String id = request.getParameter("id");
			boolean retorno = new SafraDAO().EditarAreaDeCultivo(Integer.parseInt(id), Float.parseFloat(novaArea));
			if(retorno){
				String pg = "/WEB-INF/jsp/VerSafra.jsp";
				
				request.setAttribute("dadosDoBanco", "qualquer coisa diferente de null");
			
				request.setAttribute("safra", new SafraDAO().VerSafraSelecionada(Integer.parseInt(id)));//retorna os kilos e area do cultivo 
				
				request.setAttribute("nomeCultivo", new CultivoDAO().VerCultivoComId(Integer.parseInt(id)));//retorna os dados do cultivo da safra selecionada
				
				request.setAttribute("complemento", new SafraDAO().VerDadosDosComplementosDaSafraEscolhida(Integer.parseInt(id)));//retorna os nomes dos complementos, falta a quantidade
				
				request.setAttribute("qtdComplemento", new SafraDAO().VerQuantidadeDeCadaComplemento(Integer.parseInt(id)));
				
				request.setAttribute("cultivos", new SafraDAO().CultivoJaCadastradosNaSafra());//retorna os ids e nomes dos cultivos na tabela safra
				
				
				
				RequestDispatcher dpc = request.getServletContext().getRequestDispatcher(pg);
				dpc.forward(request, response);
			}
			else{
				System.out.println("erro no update da area");
			}
		}
		else if(op.equals("kilosCultivo")){
			String id = request.getParameter("id");
			String novoValorKilos = request.getParameter("novoValorKilos");
			boolean ret = new SafraDAO().EditarQuilosDeSemente(Integer.parseInt(id), Float.parseFloat(novoValorKilos));
			if(ret){
				String pg = "/WEB-INF/jsp/VerSafra.jsp";
				
				request.setAttribute("dadosDoBanco", "qualquer coisa diferente de null");
			
				request.setAttribute("safra", new SafraDAO().VerSafraSelecionada(Integer.parseInt(id)));//retorna os kilos e area do cultivo 
				
				request.setAttribute("nomeCultivo", new CultivoDAO().VerCultivoComId(Integer.parseInt(id)));//retorna os dados do cultivo da safra selecionada
				
				request.setAttribute("complemento", new SafraDAO().VerDadosDosComplementosDaSafraEscolhida(Integer.parseInt(id)));//retorna os nomes dos complementos, falta a quantidade
				
				request.setAttribute("qtdComplemento", new SafraDAO().VerQuantidadeDeCadaComplemento(Integer.parseInt(id)));
				
				request.setAttribute("cultivos", new SafraDAO().CultivoJaCadastradosNaSafra());//retorna os ids e nomes dos cultivos na tabela safra
				
				
				
				RequestDispatcher dpc = request.getServletContext().getRequestDispatcher(pg);
				dpc.forward(request, response);
			}
			else{
				System.out.println("erro no update do kilo");
			}
		}
		
		else if(op.equals("apagar")){
			String id = request.getParameter("id");
			System.out.println("ajdiasijdsajdsidj"+id);
			boolean retorno = new SafraDAO().ApagarSafra(Integer.parseInt(id));
			if(retorno){
				System.out.println("apagado"+id);
				String pg = "/WEB-INF/jsp/VerSafra.jsp";
				
				request.setAttribute("dadosDoBanco",null);
			
				request.setAttribute("safra", new SafraDAO().VerSafraSelecionada(Integer.parseInt(id)));//retorna os kilos e area do cultivo 
				
				request.setAttribute("nomeCultivo", new CultivoDAO().VerCultivoComId(Integer.parseInt(id)));//retorna os dados do cultivo da safra selecionada
				
				request.setAttribute("complemento", new SafraDAO().VerDadosDosComplementosDaSafraEscolhida(Integer.parseInt(id)));//retorna os nomes dos complementos, falta a quantidade
				
				request.setAttribute("qtdComplemento", new SafraDAO().VerQuantidadeDeCadaComplemento(Integer.parseInt(id)));
				
				request.setAttribute("cultivos", new SafraDAO().CultivoJaCadastradosNaSafra());//retorna os ids e nomes dos cultivos na tabela safra
				
				
				
				RequestDispatcher dpc = request.getServletContext().getRequestDispatcher(pg);
				dpc.forward(request, response);
			}
			else{
				System.out.println("erro no deletar a safra");
			}
		}
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
