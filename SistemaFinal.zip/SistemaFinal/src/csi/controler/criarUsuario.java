package csi.controler;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import csi.dao.UsuarioDAO;
import csi.modelo.Usuario;

/**
 * Servlet implementation class criarUsuario
 */
@WebServlet("/criarUsuario")
public class criarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public criarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nomeUsuario = request.getParameter("nome");
		String celular = request.getParameter("celular");
		String senha = request.getParameter("senha");
		String email = request.getParameter("email");
		System.out.println(nomeUsuario+celular+senha+email);
		Usuario usuarioDoForm = new Usuario(nomeUsuario,celular,senha,email);
		
		boolean cadastrado = new UsuarioDAO().CadastrarUsuario(usuarioDoForm);
		if(cadastrado) 
		{
			String pg= "/WEB-INF/jsp/Menu.jsp";
			RequestDispatcher despacha = request.getServletContext().getRequestDispatcher(pg);
			Usuario retorno = new UsuarioDAO().VerUsuarioRecemCadastrado(usuarioDoForm); ///metodo que cria retorna o usuario que acabou de cadastrar para criar sess�o
			HttpSession sessao = request.getSession(true);
			sessao.setAttribute("logado", retorno);//sessao criada
			despacha.forward(request, response);
			
		}
		else
		{
			System.out.println("erro no cadastro");
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
