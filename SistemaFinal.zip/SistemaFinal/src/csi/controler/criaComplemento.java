package csi.controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csi.dao.ComplementoDAO;
import csi.dao.CultivoDAO;
import csi.modelo.Complemento;

@WebServlet("/criaComplemento")
public class criaComplemento extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public criaComplemento() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String escolha = request.getParameter("escolha");
		if (escolha.equals("1"))//inserir outro valor 1
		{
			chamaMetodoQueConectaNoBanco(request, response);
			String pagina = "/WEB-INF/jsp/add_Complemento.jsp";
			RequestDispatcher despacha = request.getServletContext().getRequestDispatcher(pagina);
			despacha.forward(request, response);
			//colocar mensagem que ja foi adicionados
		}
		else //volta pro menu :: valor 0
		{
			System.out.println("volta pro menu");
			chamaMetodoQueConectaNoBanco(request, response);
			String pagina = "/WEB-INF/jsp/CriaSementeComplemento.jsp";
			RequestDispatcher despacha = request.getServletContext().getRequestDispatcher(pagina);
			request.setAttribute("todosComplementos", new ComplementoDAO().VerComplementos());//metodo que retorna todos os complementos em uma array e agora vai ser jogado no jsp
			request.setAttribute("todasSementes",new CultivoDAO().VerCultivos());
			despacha.forward(request, response);
			
		}
		
	}
	public void chamaMetodoQueConectaNoBanco(HttpServletRequest request, HttpServletResponse response)
	{
		String nome = request.getParameter("nome");
		String tipo = request.getParameter("tipo");
		String marca = request.getParameter("marca");
		String observacao = request.getParameter("observacao");
		System.out.println(nome+tipo+marca+observacao);
		Complemento compl = new Complemento(nome, marca, tipo, observacao);
		boolean retorno = new ComplementoDAO().InsereComplemento(compl);
		if(retorno)
		{
			System.out.println("inserido");
		}
		else{
			System.out.println("nao inserido");
		}
	}
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
