package csi.controler;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csi.dao.ComplementoDAO;
import csi.dao.CultivoDAO;
import csi.dao.SafraDAO;
import csi.modelo.Complemento;
import csi.modelo.Cultivo;
import csi.modelo.Safra;

/**
 * Servlet implementation class salvarSafra
 */
@WebServlet("/salvarSafra")
public class salvarSafra extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public salvarSafra() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String op= request.getParameter("op");
		if(op.equals("salvar"))
		{
			System.out.println("salvar e acabo");
			String idCultivo = request.getParameter("cultivo");
			//String data = request.getParameter("cultivo");
			String area= request.getParameter("area");
			String kilosCultivo= request.getParameter("kiloscultivo");
			String idCompl= request.getParameter("iDcomplemento");
			String kilosCom = request.getParameter("kiloscomplemento"); 
			System.out.println("id do complemento>"+idCompl);
			Safra safraDoForm = new Safra(Integer.parseInt(idCultivo) ,Integer.parseInt(idCompl),Float.parseFloat(area),Float.parseFloat(kilosCultivo),Float.parseFloat(kilosCom));
			boolean ret = new SafraDAO().CriarSafra(safraDoForm);
			if(ret){
				String pagina = "/WEB-INF/jsp/Menu.jsp";
				RequestDispatcher des = request.getServletContext().getRequestDispatcher(pagina);
				des.forward(request, response);
				//mensagem deposi
			}
			else{
				System.out.println("erro ao inserir os dados no banco");
			}
			
		}
		if(op.equals("outro")){
			System.out.println("salvar e outro");
			String idCultivo = request.getParameter("cultivo");
			//String data = request.getParameter("data");
			String area= request.getParameter("area");
			String kilosCultivo= request.getParameter("kiloscultivo");
			String idCompl= request.getParameter("iDcomplemento");
			String kilosCom = request.getParameter("kiloscomplemento"); 
			System.out.println("id do complemento:"+idCompl);
			Safra safraDoForm = new Safra(Integer.parseInt(idCultivo),Integer.parseInt(idCompl),Float.parseFloat(area),Float.parseFloat(kilosCultivo),Float.parseFloat(kilosCom));
			
			boolean ret = new SafraDAO().CriarSafra(safraDoForm);
			if(ret){
				String pagina = "/WEB-INF/jsp/CriaSafra.jsp";
				RequestDispatcher des = request.getServletContext().getRequestDispatcher(pagina);
				String Formulario = "qualquer coisa diferente de null";
				request.setAttribute("formulario", Formulario);
				ArrayList<Complemento> listaDeComplemento=  new ArrayList<>(); 
				listaDeComplemento = new ComplementoDAO().VerComplementos();//retorno todos os complementos em um array
				ArrayList<Complemento> listaDosComplementoQueSobra=  new ArrayList<>(); //lista para salvar os complementos que ainda nao foram ESCOLHIDOS
				
				for (Complemento complemento : listaDeComplemento) {//laco que coloca so os que sobraram na segunda lista para exibir para o usuario
					if(complemento.getId()!=Integer.parseInt(idCompl)){
						listaDosComplementoQueSobra.add(complemento);
					}
				}
			
				request.setAttribute("botaoOutro", "qualquer coisa");//para troca o botao para pode adicionar mais sem dar bug no select
				request.setAttribute("complemento", listaDosComplementoQueSobra);
				request.setAttribute("safra", safraDoForm);
				request.setAttribute("nomeIdCultivo", new CultivoDAO().VerCultivoComId(Integer.parseInt(idCultivo)));//retorna o id e o nome do cultivo que foi escolhido
				des.forward(request, response);
				//mensagem depois
			}
			else{
				System.out.println("erro ao inserir os dados no banco");
			}
			
		}
		if(op.equals("2ouMais")){
			System.out.println("dois ou mais");
			String idCultivo = request.getParameter("cultivo");
			//String data = request.getParameter("data");
			String area= request.getParameter("area");
			String kilosCultivo= request.getParameter("kiloscultivo");
			String idCompl= request.getParameter("iDcomplemento");
			String kilosCom = request.getParameter("kiloscomplemento"); 
			System.out.println("id do complemento:"+idCompl);
			Safra safraDoForm = new Safra(Integer.parseInt(idCultivo),Integer.parseInt(idCompl),Float.parseFloat(area),Float.parseFloat(kilosCultivo),Float.parseFloat(kilosCom));
			boolean ret = new SafraDAO().CriarSafra(safraDoForm);
			if(ret){
				System.out.println("vim aqui");
				String pagina = "/WEB-INF/jsp/CriaSafra.jsp";
				
				String Formulario = "qualquer coisa diferente de null";
				request.setAttribute("formulario", Formulario); 
			    request.setAttribute("botaoOutro", "qualquer coisa");//para troca o botao para pode adicionar mais sem dar bug no select
				
			    request.setAttribute("complemento", new SafraDAO().VerificaComplementosJaAdicionados(Integer.parseInt(idCultivo)));//Lista os complementos
				request.setAttribute("safra", safraDoForm);//mostra os dados do cultivo que ja foram inseridos em inputs ready only
				request.setAttribute("nomeIdCultivo", new CultivoDAO().VerCultivoComId(Integer.parseInt(idCultivo)));//retorna o id e o nome do cultivo que foi escolhido
				RequestDispatcher des = request.getServletContext().getRequestDispatcher(pagina);
				des.forward(request, response);
				//mensagem depois
			}
			else{
				System.out.println("erro ao inserir os dados no banco 2");
			}
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
