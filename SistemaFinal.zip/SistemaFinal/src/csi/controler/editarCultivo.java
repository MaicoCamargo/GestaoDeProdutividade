package csi.controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csi.dao.ComplementoDAO;
import csi.dao.CultivoDAO;
import csi.modelo.Complemento;
import csi.modelo.Cultivo;

/**
 * Servlet implementation class editarCultivo
 */
@WebServlet("/editarCultivo")
public class editarCultivo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public editarCultivo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String op =  request.getParameter("op");//saber o que deve ser realizado
		
		if(op.equals("editarCultivo")){
			String nome = request.getParameter("nome");
			String variedade = request.getParameter("vari");
			String obs = request.getParameter("obs");
			String id = request.getParameter("id");
			Cultivo DadosCultivo = new Cultivo(nome,variedade,obs);
			DadosCultivo.setId(Integer.parseInt(id));//convertido o id para int
			String Formulario = "Cultivo";//saber qual formulariod deve aparecer na pagina
			request.setAttribute("op",Formulario);
			request.setAttribute("CultivoEditar", DadosCultivo);
			String pagina = "/WEB-INF/jsp/EditarCultivo.jsp";
			RequestDispatcher desp = request.getServletContext().getRequestDispatcher(pagina);
			desp.forward(request, response);
		}
		if(op.equals("editarComplemento"))
		{
			String nome = request.getParameter("nome");
			String marca = request.getParameter("marca");
			String tipo = request.getParameter("tipo");
			String obs = request.getParameter("obs");
			String id = request.getParameter("id");
			Complemento comp = new Complemento(nome,marca,tipo,obs);
			comp.setId(Integer.parseInt(id));
			String Formulario = "Complemento";//saber qual formulariod deve aparecer na pagina
			request.setAttribute("op",Formulario);
			request.setAttribute("ComplementoEditar", comp);
			String pagina = "/WEB-INF/jsp/EditarCultivo.jsp";
			RequestDispatcher desp = request.getServletContext().getRequestDispatcher(pagina);
			desp.forward(request, response);
			
		}
		if(op.equals("salvarEdicao")){
			String nome = request.getParameter("nome");
			String variedade = request.getParameter("vari");
			String obs = request.getParameter("obs");
			String id = request.getParameter("id");
			Cultivo DadosCultivo = new Cultivo(nome,variedade,obs);
			DadosCultivo.setId(Integer.parseInt(id));//convertido o id para int
			boolean retorno = new CultivoDAO().EditarCultivo(DadosCultivo);
			if(retorno){
				String pagina= "/WEB-INF/jsp/CriaSementeComplemento.jsp";
				RequestDispatcher des = request.getServletContext().getRequestDispatcher(pagina);
				request.setAttribute("todasSementes", new CultivoDAO().VerCultivos());
				request.setAttribute("todosComplementos", new ComplementoDAO().VerComplementos());
				des.forward(request, response);
			}
			else{
				System.out.println("algo deu errado na edicao");
			}
		}
		
		if(op.equals("salvarEdicaoComplemento")){
			String nome = request.getParameter("nome");
			String marca = request.getParameter("marca");
			String tipo = request.getParameter("tipo");
			String obs = request.getParameter("obs");
			String id = request.getParameter("id");
			Complemento comp = new Complemento(nome,marca,tipo,obs);
			comp.setId(Integer.parseInt(id));
			boolean retorno = new ComplementoDAO().EditaComplemnto(comp);
			if(retorno){
				String pagina= "/WEB-INF/jsp/CriaSementeComplemento.jsp";
				RequestDispatcher des = request.getServletContext().getRequestDispatcher(pagina);
				request.setAttribute("todasSementes", new CultivoDAO().VerCultivos());
				request.setAttribute("todosComplementos", new ComplementoDAO().VerComplementos());
				des.forward(request, response);
			}
			else{
				System.out.println("algo deu errado na edicao do complemento");
			}
		}
		if(op.equals("apagarCultivo")){
			String cod =  request.getParameter("id");
			boolean retorno = new CultivoDAO().ApagarCultivo(Integer.parseInt(cod));
			if(retorno){
				String pagina= "/WEB-INF/jsp/CriaSementeComplemento.jsp";
				RequestDispatcher des = request.getServletContext().getRequestDispatcher(pagina);
				request.setAttribute("todasSementes", new CultivoDAO().VerCultivos());
				request.setAttribute("todosComplementos", new ComplementoDAO().VerComplementos());
				des.forward(request, response);
			}
			else{
				System.out.println("algo deu errado no deletar o cultivo");
			}
			
		}
		if(op.equals("apagarComplemento")){
			String cod =  request.getParameter("id");
			boolean ret = new ComplementoDAO().ApagarComplemento(Integer.parseInt(cod));
			if(ret){
				String pagina= "/WEB-INF/jsp/CriaSementeComplemento.jsp";
				RequestDispatcher des = request.getServletContext().getRequestDispatcher(pagina);
				request.setAttribute("todasSementes", new CultivoDAO().VerCultivos());
				request.setAttribute("todosComplementos", new ComplementoDAO().VerComplementos());
				des.forward(request, response);
			}
			else{
				System.out.println("algo deu errado no deletar o complemento");
			}
		}
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
