package csi.controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import csi.dao.UsuarioDAO;
import csi.modelo.Usuario;

@WebServlet("/logarUsuario")
public class logarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public logarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }
	
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nome = request.getParameter("usuario");
		String senha = request.getParameter("senha");
		Usuario usuarioLogar= new Usuario(nome, senha);
		Usuario retorno = new UsuarioDAO().AutenticarLogin(usuarioLogar);
		//String pg="";
		
		if(retorno != null)
		{
			HttpSession sessao = request.getSession(true);
			sessao.setAttribute("logado", retorno);//sessao criada
			String pg = "/WEB-INF/jsp/Menu.jsp";
			RequestDispatcher desp =  request.getServletContext().getRequestDispatcher(pg);//para haver a troca de paginas
			desp.forward(request, response);
		}
		else
		{
			String msgDeErro= "01"; //poder ser qualquer coisa
			String pg="/index.jsp";
			request.setAttribute("msgDoServidor", msgDeErro);
			RequestDispatcher desp =  request.getServletContext().getRequestDispatcher(pg);//para haver a troca de paginas
			desp.forward(request, response);
		}
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
