package csi.modelo;

import java.util.Date;

public class Safra {

	private int id;
	private int codCultivo;
	private int codComplemento;
	private Date dataInicio;
	private float areaCultivar;
	private float kilosCultivo;
	private float kilosComplemento;
	public Safra( int codCultivo, int codComplemento, Date dataInicio, float areaCultivar, float kilosCultivo,
			float kilosComplemento) {
		super();
		
		this.codCultivo = codCultivo;
		this.codComplemento = codComplemento;
		this.dataInicio = dataInicio;
		this.areaCultivar = areaCultivar;
		this.kilosCultivo = kilosCultivo;
		this.kilosComplemento = kilosComplemento;
	}
	
	
	public Safra( int codCultivo, int codComplemento, float areaCultivar, float kilosCultivo,//sem a data usando essa
			float kilosComplemento) {
		super();
		
		this.codCultivo = codCultivo;
		this.codComplemento = codComplemento;
		this.areaCultivar = areaCultivar;
		this.kilosCultivo = kilosCultivo;
		this.kilosComplemento = kilosComplemento;
	}


	public Safra() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCodCultivo() {
		return codCultivo;
	}
	public void setCodCultivo(int codCultivo) {
		this.codCultivo = codCultivo;
	}
	public int getCodComplemento() {
		return codComplemento;
	}
	public void setCodComplemento(int codComplemento) {
		this.codComplemento = codComplemento;
	}
	public Date getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}
	public float getAreaCultivar() {
		return areaCultivar;
	}
	public void setAreaCultivar(float areaCultivar) {
		this.areaCultivar = areaCultivar;
	}
	public float getKilosCultivo() {
		return kilosCultivo;
	}
	public void setKilosCultivo(float kilosCultivo) {
		this.kilosCultivo = kilosCultivo;
	}
	public float getKilosComplemento() {
		return kilosComplemento;
	}
	public void setKilosComplemento(float kilosComplemento) {
		this.kilosComplemento = kilosComplemento;
	}
	
	
	
}
