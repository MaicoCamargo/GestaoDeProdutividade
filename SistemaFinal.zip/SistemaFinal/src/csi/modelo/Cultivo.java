package csi.modelo;

public class Cultivo {
	private int id; 
	private String nome;
	private String variedade;
	private String observacao;
	
	public Cultivo() {
		super();
	}

	public Cultivo(String nome, String variedade, String observacao) {
		super();
		this.nome = nome;
		this.variedade = variedade;
		this.observacao = observacao;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getVariedade() {
		return variedade;
	}

	public void setVariedade(String variedade) {
		this.variedade = variedade;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	
}
